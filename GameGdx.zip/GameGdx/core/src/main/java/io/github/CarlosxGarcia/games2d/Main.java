package io.github.CarlosxGarcia.games2d;

import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.utils.Array;

import java.util.Random;

public class Main extends ApplicationAdapter {
    private ShapeRenderer shapeRenderer;
    private SpriteBatch spriteBatch;
    private BitmapFont font;

    private static final int GRID_SIZE = 15;  // Smaller grid size to fit the window
    private static final int WORLD_WIDTH = 20;  // Number of columns in the grid
    private static final int WORLD_HEIGHT = 15;  // Number of rows in the grid

    private Array<Vector2> snake;
    private Vector2 food;
    private Vector2 direction;
    private boolean isGameOver = false;
    private float timer = 0;
    private static final float MOVE_INTERVAL = 0.2f;

    private int score = 0;  // Track score for food eaten
    private int highestScore = 0;  // Track the highest score

    private Random random;

    @Override
    public void create() {
        shapeRenderer = new ShapeRenderer();
        spriteBatch = new SpriteBatch();
        font = new BitmapFont(); // Default font
        font.setColor(Color.WHITE);
        font.getData().setScale(2); // Scale font for better visibility

        snake = new Array<>();
        snake.add(new Vector2(WORLD_WIDTH / 2, WORLD_HEIGHT / 2));  // Snake starts at the center
        direction = new Vector2(1, 0);  // Moving right initially
        random = new Random();

        spawnFood();
    }

    private void spawnFood() {
        // Food coordinates are aligned with the grid
        int x = random.nextInt(WORLD_WIDTH);  // Ensure food is within grid width
        int y = random.nextInt(WORLD_HEIGHT);  // Ensure food is within grid height
        food = new Vector2(x, y);

        // Ensure food doesn't spawn on the snake's body
        while (snake.contains(food, false)) {
            x = random.nextInt(WORLD_WIDTH);
            y = random.nextInt(WORLD_HEIGHT);
            food.set(x, y);
        }
    }

    @Override
    public void render() {
        if (!isGameOver) {
            timer += Gdx.graphics.getDeltaTime();
            if (timer >= MOVE_INTERVAL) {
                timer -= MOVE_INTERVAL;
                moveSnake();
            }
        }

        handleInput();

        Gdx.gl.glClearColor(0.15f, 0.15f, 0.2f, 1f);  // Set background color
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);  // Clear the screen

        drawGrid();  // Draw the grid
        drawFood();  // Draw the food
        drawSnake();  // Draw the snake
        drawScore();  // Draw the score
        if (isGameOver) {
            drawRetryButton();  // Draw the retry button if game over
        }
    }

    private void drawGrid() {
        // Center the grid by shifting the drawing position
        float offsetX = (Gdx.graphics.getWidth() - WORLD_WIDTH * GRID_SIZE) / 2;
        float offsetY = (Gdx.graphics.getHeight() - WORLD_HEIGHT * GRID_SIZE) / 2;

        shapeRenderer.begin(ShapeRenderer.ShapeType.Line);
        shapeRenderer.setColor(Color.DARK_GRAY);
        for (int x = 0; x < WORLD_WIDTH; x++) {
            for (int y = 0; y < WORLD_HEIGHT; y++) {
                shapeRenderer.rect(offsetX + x * GRID_SIZE, offsetY + y * GRID_SIZE, GRID_SIZE, GRID_SIZE);
            }
        }
        shapeRenderer.end();
    }

    private void drawFood() {
        // Center the food on the grid as well
        float offsetX = (Gdx.graphics.getWidth() - WORLD_WIDTH * GRID_SIZE) / 2;
        float offsetY = (Gdx.graphics.getHeight() - WORLD_HEIGHT * GRID_SIZE) / 2;

        shapeRenderer.begin(ShapeRenderer.ShapeType.Filled);
        shapeRenderer.setColor(Color.RED);
        shapeRenderer.rect(offsetX + food.x * GRID_SIZE, offsetY + food.y * GRID_SIZE, GRID_SIZE, GRID_SIZE);
        shapeRenderer.end();
    }

    private void drawSnake() {
        // Center the snake on the grid as well
        float offsetX = (Gdx.graphics.getWidth() - WORLD_WIDTH * GRID_SIZE) / 2;
        float offsetY = (Gdx.graphics.getHeight() - WORLD_HEIGHT * GRID_SIZE) / 2;

        shapeRenderer.begin(ShapeRenderer.ShapeType.Filled);
        shapeRenderer.setColor(Color.GREEN);
        for (Vector2 part : snake) {
            shapeRenderer.rect(offsetX + part.x * GRID_SIZE, offsetY + part.y * GRID_SIZE, GRID_SIZE, GRID_SIZE);
        }
        shapeRenderer.end();
    }

    private void drawScore() {
        spriteBatch.begin();
        
        // Draw the current score
        font.draw(spriteBatch, "Score: " + score, Gdx.graphics.getWidth() - 150, Gdx.graphics.getHeight() - 20);
        
        // Draw the highest score with some vertical space (add 20 pixels space between them)
        font.draw(spriteBatch, "Highest Score: " + highestScore, Gdx.graphics.getWidth() - 250, Gdx.graphics.getHeight() - 40 - 20);  // Adjust y-position by adding -20 for space
        
        spriteBatch.end();
    }


    private void drawRetryButton() {
        spriteBatch.begin();
        font.draw(spriteBatch, "Game Over! Press 'R' to Retry", Gdx.graphics.getWidth() / 2 - 100, Gdx.graphics.getHeight() / 2);
        spriteBatch.end();
    }

    private void moveSnake() {
        Vector2 newHead = new Vector2(snake.first()).add(direction);

        if (newHead.equals(food)) {
            snake.insert(0, newHead);  // Grow snake
            score++;  // Increase score
            spawnFood();  // Spawn new food immediately
        } else {
            snake.insert(0, newHead);
            snake.pop();  // Remove tail
        }

        // Check collisions with walls
        if (newHead.x < 0 || newHead.x >= WORLD_WIDTH || newHead.y < 0 || newHead.y >= WORLD_HEIGHT) {
            isGameOver = true;
            updateHighestScore();
        }

        // Check collisions with itself
        for (int i = 1; i < snake.size; i++) {
            if (snake.get(i).equals(newHead)) {
                isGameOver = true;
                updateHighestScore();
                break;
            }
        }
    }

    private void updateHighestScore() {
        if (score > highestScore) {
            highestScore = score;  // Update highest score if current score is higher
        }
    }

    private void handleInput() {
        if (isGameOver && Gdx.input.isKeyJustPressed(com.badlogic.gdx.Input.Keys.R)) {
            restartGame();  // Restart the game if 'R' is pressed
        }

        if (!isGameOver) {
            if (Gdx.input.isKeyJustPressed(com.badlogic.gdx.Input.Keys.UP) && direction.y != -1) {
                direction.set(0, 1);
            } else if (Gdx.input.isKeyJustPressed(com.badlogic.gdx.Input.Keys.DOWN) && direction.y != 1) {
                direction.set(0, -1);
            } else if (Gdx.input.isKeyJustPressed(com.badlogic.gdx.Input.Keys.LEFT) && direction.x != 1) {
                direction.set(-1, 0);
            } else if (Gdx.input.isKeyJustPressed(com.badlogic.gdx.Input.Keys.RIGHT) && direction.x != -1) {
                direction.set(1, 0);
            }
        }
    }

    private void restartGame() {
        score = 0;
        snake.clear();
        snake.add(new Vector2(WORLD_WIDTH / 2, WORLD_HEIGHT / 2));  // Reset snake to center
        direction.set(1, 0);  // Reset direction to right
        spawnFood();  // Spawn food
        isGameOver = false;  // Set game state to running
    }

    @Override
    public void dispose() {
        shapeRenderer.dispose();
        spriteBatch.dispose();
        font.dispose();
    }
}
