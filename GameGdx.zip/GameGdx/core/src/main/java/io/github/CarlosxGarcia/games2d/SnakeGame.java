package io.github.CarlosxGarcia.games2d;

import com.badlogic.gdx.Game;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

public class SnakeGame extends Game {
	
	public SpriteBatch batch;

    @Override
    public void create() {
        batch = new SpriteBatch();
        setScreen(new GameScreen(this)); // Initialize the game screen
    }

    @Override
    public void dispose() {
        batch.dispose();
    }	

}
