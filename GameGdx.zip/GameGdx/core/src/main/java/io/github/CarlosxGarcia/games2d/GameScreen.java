package io.github.CarlosxGarcia.games2d;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.badlogic.gdx.math.Vector2;

import java.util.ArrayList;

public class GameScreen implements Screen {
	 private final SnakeGame game;
	    private OrthographicCamera camera;
	    private ShapeRenderer shapeRenderer;

	    private ArrayList<Vector2> snake; // List to represent the snake's body
	    private Vector2 food;            // Position of the food
	    private Vector2 direction;       // Direction of the snake's movement

	    private float timer;
	    private final float MOVE_TIME = 0.2f; // Snake moves every 0.2 seconds

	    public GameScreen(SnakeGame game) {
	        this.game = game;
	        camera = new OrthographicCamera();
	        camera.setToOrtho(false, 800, 600); // Set the screen size
	        shapeRenderer = new ShapeRenderer();

	        snake = new ArrayList<>();
	        snake.add(new Vector2(5, 5)); // Start the snake with one segment
	        direction = new Vector2(1, 0); // Moving to the right
	        spawnFood();
	    }

	    private void spawnFood() {
	        food = new Vector2((int) (Math.random() * 20), (int) (Math.random() * 15));
	    }

	    @Override
	    public void render(float delta) {
	        update(delta);

	        game.batch.setProjectionMatrix(camera.combined);
	        shapeRenderer.setProjectionMatrix(camera.combined);

	        // Clear screen
	        com.badlogic.gdx.Gdx.gl.glClear(com.badlogic.gdx.graphics.GL20.GL_COLOR_BUFFER_BIT);

	        // Render snake and food
	        shapeRenderer.begin(ShapeRenderer.ShapeType.Filled);
	        for (Vector2 segment : snake) {
	            shapeRenderer.rect(segment.x * 20, segment.y * 20, 20, 20);
	        }
	        shapeRenderer.setColor(1, 0, 0, 1); // Food color: red
	        shapeRenderer.rect(food.x * 20, food.y * 20, 20, 20);
	        shapeRenderer.end();
	    }

	    private void update(float delta) {
	        timer += delta;
	        if (timer >= MOVE_TIME) {
	            timer = 0;
	            moveSnake();
	            checkCollision();
	        }

	        handleInput();
	    }

	    private void moveSnake() {
	        Vector2 newHead = new Vector2(snake.get(0)).add(direction);
	        snake.add(0, newHead); // Add a new head
	        if (newHead.equals(food)) {
	            spawnFood(); // Spawn new food if the snake eats it
	        } else {
	            snake.remove(snake.size() - 1); // Remove the tail if no food is eaten
	        }
	    }

	    private void handleInput() {
	        if (com.badlogic.gdx.Gdx.input.isKeyJustPressed(com.badlogic.gdx.Input.Keys.UP) && direction.y == 0) {
	            direction.set(0, 1);
	        }
	        if (com.badlogic.gdx.Gdx.input.isKeyJustPressed(com.badlogic.gdx.Input.Keys.DOWN) && direction.y == 0) {
	            direction.set(0, -1);
	        }
	        if (com.badlogic.gdx.Gdx.input.isKeyJustPressed(com.badlogic.gdx.Input.Keys.LEFT) && direction.x == 0) {
	            direction.set(-1, 0);
	        }
	        if (com.badlogic.gdx.Gdx.input.isKeyJustPressed(com.badlogic.gdx.Input.Keys.RIGHT) && direction.x == 0) {
	            direction.set(1, 0);
	        }
	    }

	    private void checkCollision() {
	        Vector2 head = snake.get(0);

	        // Check wall collision
	        if (head.x < 0 || head.x >= 40 || head.y < 0 || head.y >= 30) {
	            resetGame();
	        }

	        // Check self-collision
	        for (int i = 1; i < snake.size(); i++) {
	            if (head.equals(snake.get(i))) {
	                resetGame();
	            }
	        }
	    }

	    private void resetGame() {
	        snake.clear();
	        snake.add(new Vector2(5, 5));
	        direction.set(1, 0);
	        spawnFood();
	    }

	    @Override
	    public void resize(int width, int height) { }

	    @Override
	    public void pause() { }

	    @Override
	    public void resume() { }

	    @Override
	    public void hide() { }

	    @Override
	    public void dispose() {
	        shapeRenderer.dispose();
	    }

	    @Override
	    public void show() { }
}
